public class Driver {
  public static void main(String[] args) {
     Rectangle rect = new Rectangle(10, 20);
     Circle circle = new Circle(10);
     Triangle triangle = new Triangle(10, 20, 30);
     // NOTE: The actual driver program will run tests on the above objects
	System.out.println("foobar");
  }
}
